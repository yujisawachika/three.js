<template>
  <div class="about">
    <h1>This is an about page</h1>
    <FilterTag msg="Welcome to Your Vue.js App" @find_categories="find_categories"/>
     <p>選択しているカテゴリ：{{ preview }}</p>
    <ul class="entry_list">
      <li v-for="(post,index) in posts" v-show="post.display" :key="index">
        <p><a v-bind:href="post.url">{{ post.title }}</a></p>
        <ul>
          <li v-for="(tags,index) in post.tags" :key="index">{{ tags }}</li>
        </ul>
      </li>
    </ul>
    <ul>
      <!-- <li>{{ count }}</li>
      <li>{{ max }}</li> -->
    </ul>
    <h3>引数付き</h3>
    <!-- <p>{{tag}}</p> -->
    <!-- <p>{{posts}}</p> -->
    <!-- <ul>
          <li v-for="(category,index) in test" :key="index">{{ category }}</li>
        </ul> -->
    <ul>
      <!-- <li>{{ itemA }}</li>
      <li>{{ listA }}</li> -->
      <!-- <li>{{ nameA }}</li>
      <li>{{ nameB(1) }}</li> -->
    </ul>
  </div>
</template>
<script>
import FilterTag from '@/components/FilterTag.vue'
export default {
  data: function () {
    return {
      posts: this.$store.getters.items,
      // tag: this.$store.getters.lists[0].tag,
    preview: []
    }
  },
  components: {
    FilterTag
  },
  computed: {
    // 引数なしゲッター
    // count() { return this.$store.getters.count },   // 1
    // max()   { return this.$store.getters.max },     // 2
    // 引数付きゲッター
    itemA() { return this.$store.getters.item(1) }, // 1 👍 いいね
    listA() { return this.$store.getters.list(1) }, // 1 👍 いいね
    // itemB() { return this.$store.getters.item },    // 2 👎 よくないね
    // nameA() { return this.$store.getters.name(1) }, // 3 👍 いいね
    // nameB() { return this.$store.getters.name },    // 4 👎 よくないね
  },
  methods: {
    // toggleChildCheck(value) {
    //   this.check_child = value;
    //   console.log(this.check_child);
    // },
    find_categories: function(val){
      var posts = this.posts;
      var preview = val;
      console.log(val);

      if(preview.length > 0) {
        for (var i = 0; i < posts.length; i++) {
          var tags = posts[i].tag;
          for (var j = 0; j < preview.length; j++) {
            if(tags.indexOf(preview[j]) >= 0){
              posts[i].display = true;
              break;
            } else {
              posts[i].display = false;
            }
          }
        }
      } else {
        for (var k = 0; k < posts.length; k++) {
          tags = posts[k].tags;
          posts[k].display = true;
        }
      }
    }
  }
}
</script>
<style lang="scss">
.about {
  width:800px;
  margin:auto;
}
h3 {
  text-align:left;
}
ul {
  text-align:left;
  li {
    list-style:none;
  }
}
</style>