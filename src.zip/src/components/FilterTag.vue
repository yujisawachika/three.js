<template>
  <div class="tag">
    <div>
      <ul class="category_list">
        <li v-for="(category,index) in category_lists" :key="index">
          <input type="checkbox" v-bind:id="category" v-bind:value="category" v-model="preview" @click="find_categories">
          <label v-bind:for="category">{{ category }}</label>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'tag',
  props: {
    msg: String
  },
  data: function () {
    return {
    // category_lists: ['html','js','css','php'],
    category_lists: this.$store.getters.lists[0].tag,
    preview: []
    }
  },
  watch: {
    // formオブジェクト内のすべての変更を監視する
    preview: {
      handler (val, old) { // eslint-disable-line
       this.find_categories()
      },
      // deep: true
    }
  },
  methods: {
    find_categories() {
        this.$emit('find_categories', this.preview);
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
